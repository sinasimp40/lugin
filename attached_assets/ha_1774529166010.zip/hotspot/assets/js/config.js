// LaZy PORTAL CONFIGURATION

// Multi vendo 
var multiVendo = true; // SET SA TRUE KAPAG MULTIPLE VENDO

// 0 = traditional (client choose a vendo) , 1 = auto select vendo base on hotspot address, 2 = interface name ( this will preserve one hotspot server ip only)
var multiVendoOption = 2;

//list here all node mcu address for multi vendo setup
var multiVendoAddress = [
    {
        vendoName: "Denfi Wifi Kiosk", // Vendo name
        vendoIp: "10.0.0.5:8989", // Vendo Ip address
        hotspotAddress: "10.0.0.1", // use for multi vendo option = 1, means your vendo map to this hotspot and autoselect it when client connected to this
        interfaceName: "bridge-hotspot", // hotspot interface name preserved
        enableEload: false, // eload button
        enableFreeMovies: true, // free movie button
        enableVoucherVault: false, // voucher vault button
        voucherMode: false // voucher type, no coin slot setup
    },
    {
        vendoName: "Denfi Wifi", // Vendo name
        vendoIp: "10.0.10.4", // Vendo Ip address
        hotspotAddress: "10.0.10.1", // use for multi vendo option = 1, means your vendo map to this hotspot and autoselect it when client connected to this
        interfaceName: "vlan10", // hotspot interface name preserved
        enableEload: false, // eload button
        enableFreeMovies: true, // free movie button
        enableVoucherVault: false, // voucher vault button
        voucherMode: false // voucher type, no coin slot setup
    }
]

//////// FOR SINGLE VENDO SETTING ///////////
// Single vendo address
var vendoIpAddress = '10.0.0.5:8989'; // IP NG VENDO MO (FOR SINGLE VENDO USER)

// Free movie access for logged-in users
var enableFreeMovies = true; 

// For storing voucher
var enableVoucherVault = true; 

// For eload function
var enableEload = true; 

// Voucher type only, no coin slot
var voucherMode = false;
////////////////////////////////////////////

// Hotspot Name
var hotspotName = 'Denfi Wifi';

// Portal login option, 0 = username only, 1 = username + password
var loginOption = 0;

// Use device mac as voucher
var macAsVoucher = false;

// Currency symbol
var currencySymbol = '₱';

// 0 = dark , 1 = lite
var portalTheme = 0;

// No pause on voucher with this prefix
var noPausePrefix = ['PS', 'PW', 'SB', 'CR', 'T-'];

// No extend time on voucher with this prefix
var noExtendPrefix = ['TR', 'PR', 'MR', 'CR', 'T-'];

// Pause time 
var enablePause = false;
var pauseLimit = 0; // 0 = no limit

// Footer text on resume 
var footerText = 'Denfi Computer Shop | Denfi Wifi Pisonet';

// Coindrop notification
var enableCoinDrop = true;
var BotToken = '7552381899:AAGfPfS1-YPA-pAQb_y1i1OCKCymmb6m8Lc'; //palitan mo ito ng sarili mong telegram bot token
var ChatId = '-4810840343'; //palitan mo ito ng sarili mong telegram chatid

// Free trial ADS Timer
var adsCountdown = 10;



